package com.retromakers.retrofitpractice;

import retrofit2.http.GET;

public interface GitHubClient {
    @GET("")
}
